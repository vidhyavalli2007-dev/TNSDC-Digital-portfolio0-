# Student portfolio 

A Pen created on CodePen.

Original URL: [https://codepen.io/Vidhya-G-the-bold/pen/ogjQdGz](https://codepen.io/Vidhya-G-the-bold/pen/ogjQdGz).

